#-*- coding:utf-8 -*-
def test02():
    print('\033[0;31;41m ----recvmsg-test02----\033[0m')

