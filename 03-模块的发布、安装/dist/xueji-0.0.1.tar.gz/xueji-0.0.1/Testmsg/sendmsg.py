#-*- coding:utf-8 -*-
def test01():
    print('\033[0;30;40m ----sendmsg-test01----\033[0m')

