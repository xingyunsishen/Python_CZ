#-*- coding:utf-8 -*- 
from distutils.core import setup
setup(name="xueji", version="0.0.1", description="xueji's module", author="xueji", py_modules=['Testmsg.sendmsg', 'Testmsg.recvmsg'])

